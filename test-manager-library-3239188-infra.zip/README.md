# Infraestructura local

La base PostgreSQL 16 se crea vacía: este directorio no contiene scripts SQL ni inicializadores. Las tablas y las cinco categorías se crean con las migraciones de `api/`.

1. Copia `.env.example` como `.env` y reemplaza `APP_KEY`, `DB_PASSWORD`, `ADMIN_PASSWORD` (mínimo 12 caracteres) y `JWT_SECRET` (mínimo 32 bytes aleatorios; puedes generarlo con `openssl rand -hex 32`). El valor `APP_KEY` de ejemplo es solo local.
2. Ejecuta `docker compose up --build` desde este directorio.
3. En otra terminal, ejecuta `docker compose exec api php artisan migrate --force`.
4. Crea la cuenta inicial con `docker compose exec api php artisan library:bootstrap-admin`.
5. Abre el panel en `http://localhost:5173`, la página pública en `http://localhost:8080` y la salud API en `http://localhost:8000/health`.

La cuenta inicial se toma del entorno; la migración no crea administradores. La API no corre migraciones automáticamente. Portadas y base de datos se guardan en volúmenes separados.

Para datos de demostración, sigue el procedimiento de `tool/README.md`. El reloj retroactivo debe permanecer apagado fuera de una ejecución local controlada.
